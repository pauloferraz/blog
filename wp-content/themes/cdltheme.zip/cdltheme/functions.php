<?php
/**
 * CDL Theme — funções e suporte.
 *
 * @package cdltheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * URLs externas do cabeçalho (filtros para ajuste sem editar o pattern).
 */
function cdltheme_url_companhia(): string {
	return (string) apply_filters( 'cdltheme_url_companhia', 'https://www.companhiadasletras.com.br/' );
}

function cdltheme_url_educacao(): string {
	return (string) apply_filters( 'cdltheme_url_educacao', 'https://www.companhiadasletras.com.br/educacao/' );
}

/**
 * URL de arquivo de categoria.
 *
 * @param string $slug Slug da categoria.
 */
function cdltheme_category_link( string $slug ): string {
	$term = get_term_by( 'slug', $slug, 'category' );
	if ( $term && ! is_wp_error( $term ) ) {
		$link = get_term_link( $term );
		if ( ! is_wp_error( $link ) ) {
			return esc_url( $link );
		}
	}

	return esc_url( home_url( user_trailingslashit( 'category/' . $slug ) ) );
}

/**
 * URL para ícone social do rodapé (aceita '#' quando ainda não configurado).
 *
 * @param string $filter_name Nome do filtro, ex.: cdltheme_social_facebook.
 */
function cdltheme_social_href( string $filter_name ): string {
	$url = (string) apply_filters( $filter_name, '' );
	$url = trim( $url );
	if ( '' === $url || '#' === $url ) {
		return '#';
	}
	$out = esc_url( $url );

	return '' !== $out ? $out : '#';
}

/**
 * Slug do tipo de conteúdo "Seleções" (equivalente a companySelections; o core só aceita slugs em minúsculas).
 * REST: /wp/v2/company_selections
 */
function cdltheme_post_type_company_selections(): string {
	return 'company_selections';
}

/**
 * Slug do tipo de conteúdo "Rádio" (equivalente a companyRadio).
 * REST: /wp/v2/company_radio
 */
function cdltheme_post_type_company_radio(): string {
	return 'company_radio';
}

/**
 * Meta: URL Spotify (apenas company_radio).
 */
function cdltheme_radio_meta_spotify(): string {
	return 'cdl_spotify_url';
}

/**
 * Meta: URL YouTube (apenas company_radio).
 */
function cdltheme_radio_meta_youtube(): string {
	return 'cdl_youtube_url';
}

/**
 * URL do arquivo de um tipo de conteúdo publicável.
 */
function cdltheme_post_type_archive_url( string $post_type ): string {
	$link = get_post_type_archive_link( $post_type );
	return is_string( $link ) && $link !== '' ? esc_url( $link ) : esc_url( home_url( '/' ) );
}

/**
 * URL da listagem de posts (página de artigos ou arquivo).
 */
function cdltheme_posts_archive_url(): string {
	$posts_page = (int) get_option( 'page_for_posts' );
	if ( $posts_page > 0 ) {
		return esc_url( get_permalink( $posts_page ) );
	}

	if ( 'posts' === get_option( 'show_on_front' ) ) {
		return esc_url( home_url( '/' ) );
	}

	$archive = get_post_type_archive_link( 'post' );
	if ( is_string( $archive ) && $archive !== '' ) {
		return esc_url( $archive );
	}

	return esc_url( home_url( '/' ) );
}

/**
 * Meta key usada para ordenar posts mais lidos.
 */
function cdltheme_post_views_meta_key(): string {
	return 'cdltheme_post_views';
}

/**
 * Incrementa visualizações do post (apenas singular de post, sem preview).
 */
function cdltheme_track_post_views(): void {
	if ( ! is_singular( 'post' ) || is_preview() ) {
		return;
	}

	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}

	$post_id = (int) get_queried_object_id();
	if ( $post_id <= 0 ) {
		return;
	}

	$key   = cdltheme_post_views_meta_key();
	$count = (int) get_post_meta( $post_id, $key, true );
	update_post_meta( $post_id, $key, $count + 1 );
}

add_action( 'template_redirect', 'cdltheme_track_post_views' );

/**
 * IDs dos N posts com mais visualizações; completa com posts recentes se faltar.
 *
 * @param int $count Quantidade desejada.
 * @return int[]
 */
function cdltheme_get_most_read_post_ids( int $count = 5 ): array {
	$count = max( 1, $count );
	$key   = cdltheme_post_views_meta_key();

	$q = new WP_Query(
		array(
			'posts_per_page'      => $count,
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'fields'              => 'ids',
			'ignore_sticky_posts' => true,
			'meta_key'            => $key,
			'orderby'             => 'meta_value_num',
			'order'               => 'DESC',
		)
	);

	$ids = array_map( 'intval', $q->posts );

	if ( count( $ids ) < $count ) {
		$fill = new WP_Query(
			array(
				'posts_per_page'      => $count - count( $ids ),
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'post__not_in'        => $ids,
				'fields'              => 'ids',
				'ignore_sticky_posts' => true,
				'orderby'             => 'date',
				'order'               => 'DESC',
			)
		);
		$ids = array_merge( $ids, array_map( 'intval', $fill->posts ) );
	}

	return array_slice( $ids, 0, $count );
}

/**
 * Regista tipos de conteúdo personalizados dos carrosséis (Seleções e Rádio).
 */
function cdltheme_register_company_carousel_post_types(): void {
	register_post_type(
		cdltheme_post_type_company_selections(),
		array(
			'labels'              => array(
				'name'               => _x( 'Seleções', 'post type general name', 'cdltheme' ),
				'singular_name'      => _x( 'Seleção', 'post type singular name', 'cdltheme' ),
				'add_new'            => _x( 'Adicionar nova', 'company_selections', 'cdltheme' ),
				'add_new_item'       => __( 'Adicionar nova seleção', 'cdltheme' ),
				'edit_item'          => __( 'Editar seleção', 'cdltheme' ),
				'new_item'           => __( 'Nova seleção', 'cdltheme' ),
				'view_item'          => __( 'Ver seleção', 'cdltheme' ),
				'search_items'       => __( 'Pesquisar seleções', 'cdltheme' ),
				'not_found'          => __( 'Nenhuma seleção encontrada.', 'cdltheme' ),
				'not_found_in_trash' => __( 'Nenhuma seleção na lixeira.', 'cdltheme' ),
				'menu_name'          => __( 'Seleções', 'cdltheme' ),
			),
			'public'                => true,
			'publicly_queryable'  => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'show_in_nav_menus'     => false,
			'show_in_admin_bar'     => true,
			'show_in_rest'          => true,
			'rest_base'             => 'company_selections',
			'menu_icon'             => 'dashicons-images-alt2',
			'menu_position'         => 21,
			'has_archive'           => true,
			'rewrite'               => array( 'slug' => 'selecoes-companhia' ),
			'supports'              => array( 'title', 'thumbnail' ),
			'capability_type'       => 'post',
		)
	);

	register_post_type(
		cdltheme_post_type_company_radio(),
		array(
			'labels'              => array(
				'name'               => _x( 'Rádio Companhia', 'post type general name', 'cdltheme' ),
				'singular_name'      => _x( 'Item de rádio', 'post type singular name', 'cdltheme' ),
				'add_new'            => _x( 'Adicionar novo', 'company_radio', 'cdltheme' ),
				'add_new_item'       => __( 'Adicionar item de rádio', 'cdltheme' ),
				'edit_item'          => __( 'Editar item de rádio', 'cdltheme' ),
				'new_item'           => __( 'Novo item de rádio', 'cdltheme' ),
				'view_item'          => __( 'Ver item', 'cdltheme' ),
				'search_items'       => __( 'Pesquisar rádio', 'cdltheme' ),
				'not_found'          => __( 'Nenhum item encontrado.', 'cdltheme' ),
				'not_found_in_trash' => __( 'Nenhum item na lixeira.', 'cdltheme' ),
				'menu_name'          => __( 'Rádio Companhia', 'cdltheme' ),
			),
			'public'                => true,
			'publicly_queryable'    => true,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'show_in_nav_menus'     => false,
			'show_in_admin_bar'     => true,
			'show_in_rest'          => true,
			'rest_base'             => 'company_radio',
			'menu_icon'             => 'dashicons-microphone',
			'menu_position'         => 22,
			'has_archive'           => true,
			'rewrite'               => array( 'slug' => 'radio-companhia' ),
			'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'capability_type'       => 'post',
		)
	);
}
add_action( 'init', 'cdltheme_register_company_carousel_post_types' );

/**
 * Garante que os carrosséis da home consultam os CPTs certos (modelos antigos no editor podem ainda pedir "post").
 *
 * @param array    $query Args do WP_Query.
 * @param WP_Block $block Bloco core/query.
 * @param int      $page  Página.
 * @return array
 */
function cdltheme_query_loop_force_carousel_post_types( array $query, WP_Block $block, int $page ): array {
	$class = isset( $block->attributes['className'] ) ? (string) $block->attributes['className'] : '';
	
	if ( strpos( $class, 'cdl-query-company-selections' ) !== false ) {
		$query['post_type'] = cdltheme_post_type_company_selections();
	} elseif ( strpos( $class, 'cdl-query-company-radio' ) !== false ) {
		$query['post_type'] = cdltheme_post_type_company_radio();
	}
	return $query;
}
add_filter( 'query_loop_block_query_vars', 'cdltheme_query_loop_force_carousel_post_types', 5, 3 );

/**
 * Meta REST + campos no editor para URLs do item de rádio.
 */
function cdltheme_register_radio_url_meta(): void {
	$pt = cdltheme_post_type_company_radio();

	foreach ( array( cdltheme_radio_meta_spotify(), cdltheme_radio_meta_youtube() ) as $meta_key ) {
		register_post_meta(
			$pt,
			$meta_key,
			array(
				'single'            => true,
				'type'              => 'string',
				'show_in_rest'      => true,
				'auth_callback'     => static function (): bool {
					return current_user_can( 'edit_posts' );
				},
				'sanitize_callback' => static function ( $value ) {
					$value = is_string( $value ) ? trim( $value ) : '';
					if ( '' === $value ) {
						return '';
					}
					return esc_url_raw( $value );
				},
			)
		);
	}
}
add_action( 'init', 'cdltheme_register_radio_url_meta' );

/**
 * Caixa no editor para Spotify / YouTube (além do painel REST).
 */
function cdltheme_radio_urls_meta_box( WP_Post $post ): void {
	if ( cdltheme_post_type_company_radio() !== $post->post_type ) {
		return;
	}
	wp_nonce_field( 'cdltheme_radio_urls', 'cdltheme_radio_urls_nonce' );
	$spotify = (string) get_post_meta( $post->ID, cdltheme_radio_meta_spotify(), true );
	$youtube = (string) get_post_meta( $post->ID, cdltheme_radio_meta_youtube(), true );
	?>
	<p>
		<label for="cdl_spotify_url"><strong><?php esc_html_e( 'Spotify', 'cdltheme' ); ?></strong></label><br />
		<input type="url" class="widefat" id="cdl_spotify_url" name="cdl_spotify_url" value="<?php echo esc_attr( $spotify ); ?>" placeholder="https://" />
	</p>
	<p>
		<label for="cdl_youtube_url"><strong><?php esc_html_e( 'YouTube', 'cdltheme' ); ?></strong></label><br />
		<input type="url" class="widefat" id="cdl_youtube_url" name="cdl_youtube_url" value="<?php echo esc_attr( $youtube ); ?>" placeholder="https://" />
	</p>
	<?php
}

function cdltheme_add_radio_meta_box(): void {
	add_meta_box(
		'cdltheme_radio_urls',
		__( 'Links Spotify e YouTube', 'cdltheme' ),
		'cdltheme_radio_urls_meta_box',
		cdltheme_post_type_company_radio(),
		'side',
		'high',
		array(
			'__block_editor_compatible_meta_box' => true,
			'__back_compat_meta_box'             => false,
		)
	);
}
add_action( 'add_meta_boxes', 'cdltheme_add_radio_meta_box' );

/**
 * Aviso no ecrã de edição de itens de rádio (onde estão os links).
 */
function cdltheme_radio_edit_admin_notice(): void {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'post' !== $screen->base || cdltheme_post_type_company_radio() !== $screen->post_type ) {
		return;
	}
	echo '<div class="notice notice-info"><p>';
	echo esc_html__( 'Os links Spotify e YouTube ficam no painel da direita, em «Links Spotify e YouTube» (abaixo das categorias / imagem destacada). Guarde o item depois de preencher.', 'cdltheme' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'cdltheme_radio_edit_admin_notice' );

/**
 * Guarda URLs do rádio.
 */
function cdltheme_save_radio_urls_meta( int $post_id ): void {
	if ( ! isset( $_POST['cdltheme_radio_urls_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['cdltheme_radio_urls_nonce'] ) ), 'cdltheme_radio_urls' ) ) {
		return;
	}
	if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( cdltheme_post_type_company_radio() !== get_post_type( $post_id ) ) {
		return;
	}

	$spotify = isset( $_POST['cdl_spotify_url'] ) ? esc_url_raw( wp_unslash( (string) $_POST['cdl_spotify_url'] ) ) : '';
	$youtube = isset( $_POST['cdl_youtube_url'] ) ? esc_url_raw( wp_unslash( (string) $_POST['cdl_youtube_url'] ) ) : '';

	update_post_meta( $post_id, cdltheme_radio_meta_spotify(), $spotify );
	update_post_meta( $post_id, cdltheme_radio_meta_youtube(), $youtube );
}
add_action( 'save_post', 'cdltheme_save_radio_urls_meta' );

/**
 * HTML dos botões Spotify / YouTube para um item de rádio.
 */
function cdltheme_get_radio_links_markup( int $post_id ): string {
	if ( $post_id <= 0 || cdltheme_post_type_company_radio() !== get_post_type( $post_id ) ) {
		return '';
	}

	$spotify = (string) get_post_meta( $post_id, cdltheme_radio_meta_spotify(), true );
	$youtube = (string) get_post_meta( $post_id, cdltheme_radio_meta_youtube(), true );

	if ( '' === $spotify && '' === $youtube ) {
		return '';
	}

	$spotify_label = esc_html__( 'Spotify', 'cdltheme' );
	$youtube_label = esc_html__( 'YouTube', 'cdltheme' );

	$out = '<div class="wp-block-buttons cdl-carousel__links" style="margin-top:0.75rem;">';
	
	if ( '' !== $spotify ) {
		$out .= '<div class="wp-block-button cdl-carousel__link-btn is-style-outline">';
		$out .= '<a class="wp-block-button__link wp-element-button" href="' . esc_url( $spotify ) . '" target="_blank" rel="noopener noreferrer">' . $spotify_label . '</a>';
		$out .= '</div>';
	}
	
	if ( '' !== $youtube ) {
		$out .= '<div class="wp-block-button cdl-carousel__link-btn is-style-outline">';
		$out .= '<a class="wp-block-button__link wp-element-button" href="' . esc_url( $youtube ) . '" target="_blank" rel="noopener noreferrer">' . $youtube_label . '</a>';
		$out .= '</div>';
	}
	
	$out .= '</div>';

	return $out;
}

/**
 * Injeta links Spotify/YouTube dentro dos slides do carrossel de rádio.
 * O filtro adiciona os links automaticamente ao renderizar cada slide.
 *
 * @param string   $content HTML do grupo.
 * @param array    $block   Bloco parseado.
 * @param WP_Block $instance Instância.
 */
function cdltheme_render_block_radio_slide_append_links( string $content, array $block, WP_Block $instance ): string {
	// Só processa blocos core/group
	if ( ( $block['blockName'] ?? '' ) !== 'core/group' ) {
		return $content;
	}
	
	// Verifica se é um slide de rádio
	$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( strpos( $class, 'cdl-carousel__slide--radio' ) === false ) {
		return $content;
	}
	
	// Evita duplicação (se os links já foram injetados)
	if ( strpos( $content, 'cdl-carousel__links' ) !== false ) {
		return $content;
	}
	
	// Valida o post atual
	$post_id = (int) get_the_ID();
	if ( $post_id <= 0 || cdltheme_post_type_company_radio() !== get_post_type( $post_id ) ) {
		return $content;
	}
	
	// Gera e injeta os links antes do fechamento da div
	$extra = cdltheme_get_radio_links_markup( $post_id );
	if ( '' === $extra ) {
		return $content;
	}
	
	// Injeta antes da tag de fechamento </div>
	$pos = strrpos( $content, '</div>' );
	if ( false === $pos ) {
		return $content . $extra;
	}
	
	return substr_replace( $content, $extra, $pos, 0 );
}
add_filter( 'render_block', 'cdltheme_render_block_radio_slide_append_links', 20, 3 );

add_action(
	'after_switch_theme',
	static function (): void {
		flush_rewrite_rules();
	}
);

add_action(
	'after_setup_theme',
	static function (): void {
		load_theme_textdomain( 'cdltheme', get_theme_file_path( 'languages' ) );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
		add_editor_style( 'assets/css/editor-style.css' );
		add_editor_style( 'assets/css/home.css' );
	}
);

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		$ver = wp_get_theme()->get( 'Version' );
		wp_enqueue_style(
			'cdltheme-header',
			get_theme_file_uri( 'assets/css/header.css' ),
			array(),
			$ver
		);
		wp_enqueue_style(
			'cdltheme-footer',
			get_theme_file_uri( 'assets/css/footer.css' ),
			array( 'cdltheme-header' ),
			$ver
		);

		if ( is_front_page() || is_home() ) {
			wp_enqueue_style(
				'cdltheme-home',
				get_theme_file_uri( 'assets/css/home.css' ),
				array( 'cdltheme-footer' ),
				$ver
			);
			wp_enqueue_script(
				'cdltheme-home-carousel',
				get_theme_file_uri( 'assets/js/home-carousel.js' ),
				array(),
				$ver,
				true
			);
		}
	}
);
